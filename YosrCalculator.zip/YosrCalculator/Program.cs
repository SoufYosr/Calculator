﻿/*******************************************************
 * Name:        Yosr Souf
 * Student ID:  E#00750030
 * Class:       CSCI-2210
 * Assignment:  Dispatch Table Calculator
 * Date:        04-19-2025
 * Date Modified: 4-29-2025
 * Description: An implementation of a calculator with some advanced functionality.
 *******************************************************/
using System.Threading.Tasks;

namespace YosrCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();  // create a new calculator instance

            string mode = SelectMode(); //ask the user to choose between normal or RPN mode


            LoadSavedVariables(calculator); // optionally load and display saved variables

            Func<double, double, double> adder = calculator.Add;
            Func<double, double, double> subtractor = calculator.Subtract;
            Func<double, double, double> multiplier = calculator.Multiply;
            Func<double, double, double> dividor = calculator.Divide;
            Func<double, double, double> mod = calculator.Mod;
            Func<double, double, double> exponentiator = calculator.Exponentiate;

            // create a dispatch table to associate string commands with corresponding operations
            Dictionary<string, Func<double, double, double>> dispatchTable = new Dictionary<string, Func<double, double, double>>();
            dispatchTable["add"] = adder;
            dispatchTable["sub"] = subtractor;
            dispatchTable["multiply"] = multiplier;
            dispatchTable["div"] = dividor;
            dispatchTable["mod"] = mod;
            dispatchTable["exp"] = exponentiator;

            while (true)
            {
                if (mode == "normal")
                {
                    // display available operations and control commands
                    Console.WriteLine("Choose operation:" +
                        "\n     add" +
                        "\n     sub" +
                        "\n     multiply" +
                        "\n     div" +
                        "\n     mod" +
                        "\n     exp" +
                        "\n     type 'clear' to clear your current state:" +
                        "\n     type 'undo' to undo the last operation" +
                        "\n     type 'mode' to switch calculator mode" +
                        "\n     type 'off' to turn your calculator off");

                    string operation = Console.ReadLine();

                    if (!HandleOperation(operation, calculator, dispatchTable)) // perform the operation and check if the user chose to exit
                    {
                        break;
                    }
                }
                else if (mode == "rpn")
                {
                    Console.WriteLine("Enter your RPN expression (or type 'off' to exit):");
                    string expression = Console.ReadLine();
                    if (expression.ToLower() == "off")
                    {
                        HandleOperation("off", calculator, dispatchTable);
                        break;
                    }

                    try
                    {
                        double result = calculator.EvalRPN(expression);
                        calculator.ans = result;
                        Console.WriteLine($"Result: {result}");
                        StoreResult(calculator);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error evaluating RPN expression: {ex.Message}");
                    }
                }


                // ask if the user wants to change the mode after each operation
                while (true)
                {
                    Console.WriteLine("Do you want to change mode? (yes/no)");
                    string changeMode = Console.ReadLine().Trim().ToLower();

                    if (changeMode == "yes")
                    {
                        mode = SelectMode();
                        break;
                    }
                    else if (changeMode == "no")
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid answer. Please enter 'yes' or 'no'.");
                    }
                }
            }
        }

        /// <summary>
        /// Loads saved variables from file and optionally displays them
        /// </summary>
        /// <param name="calculator">The calculator instance</param>
        static void LoadSavedVariables(Calculator calculator)
        {
            calculator.ReadFromFile(calculator.variables);

            if (calculator.variables.Count > 0)
            {
                Console.WriteLine("Do you want to load saved variables so you can use them? (yes/no)");
                if (Console.ReadLine().ToLower() == "yes")
                {
                    calculator.ReadFromFile(calculator.variables);
                }

                foreach (var kvp in calculator.variables)
                {
                    Console.WriteLine($"{kvp.Key} = {kvp.Value}");
                }
                Console.WriteLine("----------------------\n\n");
            }
        }

        /// <summary>
        /// Allows the user to set the current state to a saved variable
        /// </summary>
        /// <param name="calculator">The calculator instance</param>
        static void TrySetCurrentState(Calculator calculator)
        {
            Console.WriteLine("Enter variable name:");
            string varName = Console.ReadLine().ToLower().Trim();

            if (calculator.variables.ContainsKey(varName))
            {
                calculator.SetAns(varName);
                Console.WriteLine($"Current state set to variable '{varName}' with value {calculator.ans}.");
            }
            else
            {
                Console.WriteLine($"Variable '{varName}' does not exist.");

                Console.WriteLine("Do you want to try again? (yes/no)");
                if (Console.ReadLine().ToLower() == "yes")
                {
                    TrySetCurrentState(calculator); // recursive call
                }
                else
                {
                    Console.WriteLine("Current state not changed.");
                }
            }
        }

        /// <summary>
        /// Gets a numerical input from the user
        /// </summary>
        /// <param name="calculator">The calculator instance</param>
        /// <returns>The double value chosen by the user</returns>
        static double GetInput(Calculator calculator)
        {
            Console.WriteLine("Enter value (number, variable, or 'ans'):");
            string input = Console.ReadLine();
            if (input == "ans")
            {
                return calculator.ans;
            }
            else if (calculator.variables.ContainsKey(input))
            {
                return calculator.GetValue(input);
            }
            else
            {
                if (double.TryParse(input, out double number))
                {
                    return number;
                }
                else
                {
                    Console.WriteLine("Invalid number input.");
                    return GetInput(calculator);
                }
            }
        }

        /// <summary>
        /// Handles different calculator operations based on user input
        /// </summary>
        /// <param name="operation">The operation string entered by the user</param>
        /// <param name="calculator">The calculator instance</param>
        /// <param name="dispatchTable">A dictionary mapping operation names to functions</param>
        /// <returns>True to continue, false to exit</returns>
        static bool HandleOperation(string operation, Calculator calculator, Dictionary<string, Func<double, double, double>> dispatchTable)
        {
            if (operation == "off")
            {
                Console.WriteLine("Do you want to save your variables before exiting? (yes/no)");
                if (Console.ReadLine().ToLower() == "yes")
                {
                    calculator.WriteToFile(calculator.variables);
                    Console.WriteLine("Variables saved.");
                }
                return false; // exit
            }
            else if (operation == "clear")
            {
                calculator.Clear();
                Console.WriteLine("Calculator state has been cleared.");
                return true; // continue
            }
            else if (operation == "undo")
            {
                calculator.Undo();
                return true; // continue
            }

            else if (operation == "mode")
            {
                Console.WriteLine("Switching calculator mode...");
                string newMode = SelectMode();
                return true;
            }

            else if (dispatchTable.ContainsKey(operation))
            {
                //Console.WriteLine("Enter first value (number, variable, or 'ans'):");
                double a = GetInput(calculator);

                //Console.WriteLine("Enter second value (number, variable, or 'ans'):");
                double b = GetInput(calculator);

                try
                {
                    calculator.undoStack.Push(calculator.ans); //save current ans before changin it
                    double result = dispatchTable[operation](a, b);
                    calculator.ans = result;
                    Console.WriteLine($"Result: {result}");
                    StoreResult(calculator);
                }
                catch (DivideByZeroException ex)
                {
                    Console.WriteLine($"Math Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Unexpected error: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("Unknown operation.");
            }

            return true; // continue
        }

        /// <summary>
        /// Stores the result in a variable if the user chooses to
        /// </summary>
        /// <param name="calculator">The calculator instance</param>
        static void StoreResult(Calculator calculator)
        {
            Console.WriteLine("Do you want to store the result in a variable? (yes/no)");
            if (Console.ReadLine().ToLower() != "yes")
                return;

            Console.WriteLine("Enter variable name (lowercase letters only):");
            string varName = Console.ReadLine().ToLower().Trim();

            if (calculator.variables.ContainsKey(varName))
            {
                Console.WriteLine($"Variable '{varName}' already exists. Do you want to overwrite it? (yes/no)");
                string response = Console.ReadLine().ToLower();

                if (response == "no")
                {
                    Console.WriteLine("Would you like to give it a new name? (yes/no)");
                    string renameResponse = Console.ReadLine().ToLower();

                    if (renameResponse == "yes")
                    {
                        // Recursively call StoreResult again
                        StoreResult(calculator);
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Variable not overwritten or renamed.");
                        return;
                    }
                }
            }

            if (calculator.StoreKeyValuePair(varName))
            {
                Console.WriteLine($"Variable '{varName}' saved with value {calculator.ans}.");
            }
            else
            {
                Console.WriteLine("Invalid or duplicate variable name. Operation aborted.");
            }
        }

        /// <summary>
        /// Allows the user to select the calculator mode (normal or RPN)
        /// </summary>
        /// <returns>The selected mode as a string</returns>
        static string SelectMode()
        {
            Console.WriteLine("Choose calculator mode:");
            Console.WriteLine("1 - Normal Notation (e.g., 5 + 3)");
            Console.WriteLine("2 - Reverse Polish Notation (RPN) (e.g., 5 3 +)");
            Console.WriteLine("Enter 1 or 2:");

            string modeChoice = Console.ReadLine()?.Trim();

            if (modeChoice == "1")
            {
                Console.WriteLine("Normal Notation Mode selected.");
                return "normal";
            }
            else if (modeChoice == "2")
            {
                Console.WriteLine("Reverse Polish Notation Mode selected.");
                return "rpn";
            }
            else
            {
                Console.WriteLine("Invalid choice.");
                return SelectMode();
            }
        }


    }
}
