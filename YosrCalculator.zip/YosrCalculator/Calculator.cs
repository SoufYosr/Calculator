﻿using System.Text.RegularExpressions;

namespace YosrCalculator
{
    internal class Calculator
    {
        public double ans; //Holds the result of the most recent operation.
        public double currentState; //Represents the current state of the calculator
        public Dictionary<string, double> variables = new Dictionary<string, double>(); //Dictionary to store variables and their values.
        public Stack<double> undoStack = new Stack<double>(); // Stack to store previous answers and use them to undo operation


        /// <summary>
        /// Initializes the calculator with default values
        /// </summary>
        public Calculator()
        {
            ans = 0;
            currentState = 0;
        }

        /// <summary>
        /// Resets the result of the calculator to zero
        /// </summary>
        public void Clear()
        {
            ans = 0;
        }

        /// <summary>
        /// Adds two numbers and returns the result
        /// </summary>
        /// <param name="a">The first number to add</param>
        /// <param name="b">The second number to add</param>
        /// <returns>The sum of a and b</returns>
        public double Add(double a, double b)
        {
            return a + b;
        }

        /// <summary>
        /// Subtracts the second number from the first
        /// </summary>
        /// <param name="a">First number</param>
        /// <param name="b">Second number</param>
        /// <returns>Difference between a and b</returns>
        public double Subtract(double a, double b)
        {
            return a - b;
        }

        /// <summary>
        /// Multiplies two numbers
        /// </summary>
        /// <param name="a">First number</param>
        /// <param name="b">Second number</param>
        /// <returns>Product of a and b</returns>
        public double Multiply(double a, double b)
        {
            return a * b;
        }

        /// <summary>
        /// Divides the first number by the second
        /// </summary>
        /// <param name="a">Dividend</param>
        /// <param name="b">Divisor</param>
        /// <returns>Quotient of a and b</returns>
        /// <exception cref="DivideByZeroException">Thrown when b is 0</exception>
        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                throw new DivideByZeroException("Cannot divide by zero.");
            }

            return a / b;
        }

        /// <summary>
        /// Computes the remainder of division between two numbers
        /// </summary>
        /// <param name="a">Dividend</param>
        /// <param name="b">Divisor</param>
        /// <returns>Remainder after dividing a by b</returns>
        public double Mod(double a, double b)
        {
            return a % b;
        }

        /// <summary>
        /// Raises a to the power of b
        /// </summary>
        /// <param name="a">Base number</param>
        /// <param name="b">Exponent</param>
        /// <returns>a raised to the power of b</returns>
        public double Exponentiate(double a, double b)
        {
            return Math.Pow(a, b);
        }

        /// <summary>
        /// Stores the current answer in the dictionary with the given variable name
        /// </summary>
        /// <param name="variableName">Variable name (must be lowercase letters)</param>
        /// <returns>True if stored successfully, false otherwise</returns>
        public bool StoreKeyValuePair(string variableName)
        {
            if (!Regex.IsMatch(variableName, "^[a-z]+$")) //to only allow lowercase for variables names
            {
                Console.WriteLine("Unknown variable name.Only lowercase letters allowed.");
                return false;
            }

            variables[variableName] = ans;
            return true;
        }

        /// <summary>
        /// Retrieves the value of a stored variable
        /// </summary>
        /// <param name="variableName">Variable name</param>
        /// <returns>Value of the variable or 0 if not found</returns>
        public double GetValue(string variableName)
        {
            if (variables.ContainsKey(variableName))
            {
                return variables[variableName];
            }
            else
            {
                Console.WriteLine($"Unknown variable '{variableName}'");
                return 0; // or throw an exception or handle as needed
            }
        }


        /// <summary>
        /// Sets the current answer to the value of a stored variable
        /// </summary>
        /// <param name="variableName">Variable name to load</param>
        public void SetAns(string variableName)
        {
            if (variables.ContainsKey(variableName))
            {
                ans = variables[variableName];
                currentState = ans;
                Console.WriteLine($"Current state is now '{currentState}'");
            }
            else
            {
                Console.WriteLine($"Unknown variable '{variableName}'");
            }
        }


        /// <summary>
        /// Writes all stored variables to a text file
        /// </summary>
        /// <param name="variables">Dictionary of variables to save</param>
        public void WriteToFile(Dictionary<string, double> variables)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter("../../../variablesFile.txt"))
                {
                    writer.WriteLine("name, value");

                    foreach (KeyValuePair<string, double> kvp in variables)
                    {
                        writer.WriteLine($"{kvp.Key},{kvp.Value}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to save variables to file: {ex.Message}");
            }
        }

        /// <summary>
        /// Reads variables from a text file and loads them into the provided dictionary
        /// </summary>
        /// <param name="variables">Dictionary to populate with loaded variables</param>
        /// <returns>The updated dictionary</returns>
        public Dictionary<string, double> ReadFromFile(Dictionary<string, double> variables)
        {
            try
            {
                using (StreamReader reader = new StreamReader("../../../variablesFile.txt"))
                {
                    //to skip header 
                    reader.ReadLine();

                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        string[] parts = line.Split(',');

                        if (parts.Length == 2)
                        {
                            string variableName = parts[0];
                            if (double.TryParse(parts[1], out double value))
                            {
                                variables[variableName] = value;
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine($"Failed to load saved variables: {ex.Message}");
            }

            return variables;
        }

        /// <summary>
        /// Reverts the answer to the previous state using the undo stack
        /// </summary>
        public void Undo()
        {
            if (undoStack.Count > 0)
            {
                ans = undoStack.Pop(); // Revert to the previous state
                Console.WriteLine($"Undo successful. Current state: {ans}");
            }
            else
            {
                Console.WriteLine("No operations to undo.You haven't performed any calculations yet.");
            }
        }

        /// <summary>
        /// Evaluates Reverse Polish Notation
        /// </summary>
        /// <param name="expression">RPN expression</param>
        /// <returns>Result of the expression evaluation</returns>
        /// <exception cref="DivideByZeroException">Thrown when dividing or modding by zero</exception>
        public double EvalRPN(string expression)
        {
            string[] tokens = expression.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            Stack<double> bucket = new Stack<double>();

            for (int i = 0; i < tokens.Length; i++)
            {
                string token = tokens[i];

                if (double.TryParse(token, out double number))
                {
                    bucket.Push(number);
                }
                else
                {
                    if (bucket.Count < 2)
                    {
                        Console.WriteLine($"Not enough operands before operator '{token}'");
                        return ans;
                    }


                    double second = bucket.Pop();
                    double first = bucket.Pop();
                    double result = 0;

                    try
                    {
                        switch (token)
                        {
                            case "+":
                                result = first + second;
                                break;
                            case "-":
                                result = first - second;
                                break;
                            case "*":
                                result = first * second;
                                break;
                            case "/":
                                if (second == 0) throw new DivideByZeroException("Cannot divide by zero.");
                                result = first / second;
                                break;
                            case "%":
                                if (second == 0) throw new DivideByZeroException("Cannot modulo by zero.");
                                result = first % second;
                                break;
                            case "^":
                                result = Exponentiate(first, second);
                                break;                            
                            default:
                                Console.WriteLine($"Unsupported RPN operator '{token}'");
                                return ans;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                        return ans;
                    }

                    bucket.Push(result);
                }
            }
            return bucket.Count > 0 ? bucket.Peek() : ans;

        }
    }
}

